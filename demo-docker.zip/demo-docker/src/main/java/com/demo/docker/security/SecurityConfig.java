package com.demo.docker.security;

import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("admin").password(passwordEncoder().encode("admin"))
				.authorities("ROLE_ADMIN").and().withUser("user").password(passwordEncoder().encode("user"))
				.authorities("ROLE_USER");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {

		 http.authorizeRequests()
				.requestMatchers(EndpointRequest.to("info", "health", "prometheus")).permitAll()
				.antMatchers("/", "/ws", "v2/api-docs", "/v3/api-docs", "/webjars/***", "/csrf").permitAll()
				.regexMatchers(".*\\?wsdl", ".*swagger.*", ".*stylesheet.*").permitAll()
				.regexMatchers("/admin/*", "/login/*").hasAuthority("ROLE_ADMIN")
				.anyRequest().authenticated().and()
				.httpBasic().and().csrf().disable().cors();

	}

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	
	/*
	 * @Bean public CorsConfigurationSource corsConfigurationSource() { final
	 * CorsConfiguration configuration = new CorsConfiguration();
	 * configuration.setAllowedOrigins(Arrays.asList("*"));
	 * configuration.setAllowedMethods(Arrays.asList("HEAD", "GET", "POST", "PUT",
	 * "DELETE", "PATCH")); // setAllowCredentials(true) is important, otherwise: //
	 * The value of the 'Access-Control-Allow-Origin' header in the response must
	 * not be the wildcard '*' when the request's credentials mode is 'include'.
	 * configuration.setAllowCredentials(true); // setAllowedHeaders is important!
	 * Without it, OPTIONS preflight request // will fail with 403 Invalid CORS
	 * request configuration.setAllowedHeaders(Arrays.asList("Authorization",
	 * "Cache-Control", "Content-Type")); final UrlBasedCorsConfigurationSource
	 * source = new UrlBasedCorsConfigurationSource();
	 * source.registerCorsConfiguration("/**", configuration); return source; }
	 */
	  

}
